<template>
  <div id="app">
     <footer class="footer">
    </footer>
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return{}
  },
  created:function(){
   // var that=this;
    //this.$axios.post("/footer").then(res=>{
    //  console.log(res);
    //});
    this.axios.post('/json/footer').then((response) => {
      console.log(response.data)
    }).catch((error) => {
      console.error(error)
    })


  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
